<?php
$username=filter_input(INPUT_POST,'username');
$password=filter_input(INPUT_POST,'password');
if(!empty($username)){
    if(!empty($password))   {
        $host='localhost';
$dbusername='root';
$dbpasssword='';
$dbname='javatpoint';
$conn=new mysqli ($host,$dbusername,$dbpasssword);

if(mysqli_connect_error()){
    die('connection error ('.mysqli_connect_errno().')'.mysqli_connect_error());

}
else{
    $sql="INSERT INTO login (username,password)values ('$username','$password')";
    $conn=new mysqli ($host,$dbusername,$dbpasssword,$dbname);
    if($conn->query ($sql)){
        echo"sign up successfully";
       
    }
    else{
        echo"error".$sql."<br>".$conn->error;
    }
    $conn->close();

}
    }
    else{
        echo"ghjkpne";
        die();
    }
}
else{
    echo"nayemmollah";
    die();
}

?>
